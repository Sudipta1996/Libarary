﻿using LibraryMangemntWebApiBackend.Model;
using System.Collections.Generic;

namespace LibraryMangemntWebApiBackend.Repostiory
{
    public interface IDataRepository<T>
    {
        void AddBook(Book book);
        IEnumerable <Book> GetAll();
        
        Book GetBook(int id);
        void DeleteBook(int id);
        void UpdateBook(Book book);
        
        
    }
    
}
