﻿using LibraryMangemntWebApiBackend.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace LibraryMangemntWebApiBackend.Repostiory
{
    public class BookRepository : IDataRepository<Book>
    {
        private BookDbConetext context;
        private DbSet<Book> bookentity;
        public BookRepository(BookDbConetext conetext)
        {
            this.context = conetext;
            bookentity = conetext.Set<Book>();
        }

        public void AddBook(Book book)
        {
            context.Entry(book).State = EntityState.Added;
            context.SaveChanges();
        }

        public void DeleteBook(int id)
        {
            Book book = GetBook(id);
            bookentity.Remove(book);
            context.SaveChanges();
        }

        public IEnumerable<Book> GetAll()
        {
            return bookentity.AsEnumerable();
        }

        public Book GetBook(int id)
        {
            return bookentity.SingleOrDefault(s => s.BookId == id);
        }

        public void UpdateBook(Book book)
        {
            context.SaveChanges();
        }
    }
}

