﻿using LibraryMangemntWebApiBackend.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace LibraryMangemntWebApiBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly BookDbConetext _context;

        public BookController(BookDbConetext db)
        {
            _context = db;
        }
        [HttpGet]
        public async Task <IActionResult> Get()
        {
            return Ok(await _context.Books.ToListAsync());
        }
        [HttpPost]
        public async Task<IActionResult> Post(Book book)
        {
            _context.Books.Add(book);
             _context.SaveChanges();
            return Ok(book);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return BadRequest("Books Not Found");
            }
            return Ok(book);
        }

    }
}
