﻿using Microsoft.EntityFrameworkCore;

namespace LibraryMangemntWebApiBackend.Model
{
    public class BookDbConetext : DbContext
    {
        public BookDbConetext(DbContextOptions<BookDbConetext> options) : base(options)
        {

        }
        public DbSet<Book> Books { get; set; }

    }
}
