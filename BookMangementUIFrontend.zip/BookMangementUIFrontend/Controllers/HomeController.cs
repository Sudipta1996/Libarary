﻿using BookMangementUIFrontend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BookMangementUIFrontend.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }


        public async Task<IActionResult> Index()
        {
            List<Book> bookList = new List<Book>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:29646/api/book/"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    bookList = JsonConvert.DeserializeObject<List<Book>>(apiResponse);
                }
            }
            return View(bookList);
        }
        public ViewResult AddBook()
        {

            return View();
        }
        [HttpPost]
        public async Task <IActionResult> AddBook(Book book)
        {
            Book book2 = new Book();
            using (var httpClient = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(book), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PostAsync("http://localhost:29646/api/book/", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }
            }
            return View(book2);
        }

        public ViewResult GetBook()
        {
            return View();
        }
        [HttpPut]
        public async Task<IActionResult> UpdateBook(int id)
        {
            Book book = new Book();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("http://localhost:29646/api/book/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    book = JsonConvert.DeserializeObject<Book>(apiResponse);
                }

            }
            return View(book);
        }
        [HttpPost]
        public async Task<IActionResult> UpdateBook(Book book)
        {
            Book receivedBook = new Book();
            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(receivedBook.BookId.ToString()), "BookId");
                content.Add(new StringContent(receivedBook.BookName), "BookName");
                content.Add(new StringContent(receivedBook.AuthorName), "AuthorName");
                content.Add(new StringContent(receivedBook.ISBN.ToString()), "ISBN");

                using (var response = await httpClient.PostAsync("http://localhost:29646/api/book/", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    ViewBag.Result = "Success";
                    receivedBook = JsonConvert.DeserializeObject<Book>(apiResponse);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> DeleteBook(int Id)
        {
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("http://localhost:29646/api/book/" + Id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }
            }

            return RedirectToAction("Index");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
